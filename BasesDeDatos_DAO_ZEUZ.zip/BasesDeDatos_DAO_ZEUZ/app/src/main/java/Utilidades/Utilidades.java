package Utilidades;

public class Utilidades {
    public final static String NOMBRE_TABLA="Contactos";
    public static final String[] COLUMNS_NAME_CONTACTO =
            {
                    "_id", "usuario", "email", "tel", "fecNacimiento"
            };



    public final static String campoId="id";
    public final static String campoUsuario="usuario";
    public final static String campoEmail="email";
    public final static String campoTelefono="telefono";
    public final static  String campoFecha="fechaNacimiento";
    public final static  String SCRIPT_DB = "create table Contactos (" +
            "_id integer primary key autoincrement," +
            "usuario text not null," +
            "email text not null," +
            "tel text not null," +
            "fecNacimiento date);"
            ;

}
