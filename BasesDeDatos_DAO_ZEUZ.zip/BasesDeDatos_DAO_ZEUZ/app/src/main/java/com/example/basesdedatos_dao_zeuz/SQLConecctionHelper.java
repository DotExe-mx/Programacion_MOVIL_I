package com.example.basesdedatos_dao_zeuz;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import Utilidades.Utilidades;

public class SQLConecctionHelper extends SQLiteOpenHelper {

    /*
    la clase SQLConnectionHelpes que extiende de SQLiteOpenHelper es un auxiliar que nos ayuda a verificar en una primera instancia si la base de datos ya existe en el
    sistema, si no existe procedera a crearla utilizando la constante "CREAR_TABLA_CONTACTO" para crearla.
    Ademas esta clase nos ayuda a verificar si existe anteriormente una base de datos esto solo para poder volver a versiones anteriores, etc.
     */


    public SQLConecctionHelper(@Nullable Context context){
        super(context, "BD_Contactos", null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Utilidades.SCRIPT_DB);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


    }

}
