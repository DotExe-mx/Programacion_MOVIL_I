package com.example.basesdedatos_dao_zeuz;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnInsertar;
    Button btnMostrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnInsertar = (Button) findViewById(R.id.btnAgregar);
        btnMostrar = (Button) findViewById(R.id.btnBuscar);
        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inte = new Intent(getApplicationContext(), second_activity.class);
                inte.putExtra("idAccion", "3");
                startActivityForResult(inte, 3);

            }
        });
        btnInsertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inte = new Intent(getApplicationContext(), second_activity.class);
                inte.putExtra("idAccion", "1");
                startActivityForResult(inte, 1);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK && data.getStringExtra("Resultado").equals("1")) {
                Toast.makeText(this, "CONTACTO GUARDADO CORRECTAMENTE", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == 3) {
            if (resultCode == Activity.RESULT_OK && data.getStringExtra("Resultado").equals("3")) {
                Toast.makeText(this, "CONTACTO ELIMINADO CORRECTAMENTE", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
