package com.example.basesdedatos_dao_zeuz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import Utilidades.Utilidades;

public class DaoContacto {
    Context ct;
    SQLiteDatabase db;
    public DaoContacto(Context ct){
        this.ct=ct;
        db=new SQLConecctionHelper(ct).getWritableDatabase();
    }
    public long insertarContacto(Contacto contacto){
        ContentValues contentValues = new ContentValues();
        contentValues.put(Utilidades.COLUMNS_NAME_CONTACTO[1], contacto.getUsuario());
        contentValues.put(Utilidades.COLUMNS_NAME_CONTACTO[2], contacto.getEmail());
        contentValues.put(Utilidades.COLUMNS_NAME_CONTACTO[3], contacto.getTel());
        contentValues.put(Utilidades.COLUMNS_NAME_CONTACTO[4],contacto.getFecNac());
        return  db.insert(Utilidades.NOMBRE_TABLA,
                Utilidades.campoId, contentValues);
    }
    public List<Contacto> obtenerTodos(){
        List<Contacto> lst=null;
        Cursor c = db.query(Utilidades.NOMBRE_TABLA,
                Utilidades.COLUMNS_NAME_CONTACTO, null, null, null, null, null, null);
        if (c.moveToFirst() ){
            lst = new ArrayList<Contacto>();
            do { Contacto contacto = new Contacto(c.getInt(0), c.getString(1),c.getString(2), c.getString(3),c.getString(4));
                lst.add(contacto);
            }while(c.moveToNext());
        }
        return  lst;
    }
    public void deleteTitle(String name)
    {
        db.execSQL("DELETE FROM " + Utilidades.NOMBRE_TABLA+ " WHERE "+Utilidades.COLUMNS_NAME_CONTACTO[1]+"='"+name+"'");
        db.close();
    }
    }


