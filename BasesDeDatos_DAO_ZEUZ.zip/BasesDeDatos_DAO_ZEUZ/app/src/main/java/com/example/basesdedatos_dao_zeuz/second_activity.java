package com.example.basesdedatos_dao_zeuz;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class second_activity extends AppCompatActivity {
    DaoContacto dao;
    List<Contacto> arregloDeContactos;
    ArrayList<String>arreglo;
    ArrayAdapter<String>adapter;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
if(obtenerIDView()==1){
    setContentView(R.layout.insert_activity);
    lanzarFuncionInsert();
}
else if(obtenerIDView()==3){
    setContentView(R.layout.show_items_activity);
    lanzarFuncionMostrarTodo();
}
    }
    public int obtenerIDView(){
        String idAccion=getIntent().getStringExtra("idAccion");
        if(idAccion.equals("1")){
            Toast.makeText(getApplicationContext(),"has dado en insertar",Toast.LENGTH_SHORT);
            return 1;
        }else if (idAccion.equals("2")){
            Toast.makeText(getApplicationContext(),"has dado en Eliminar",Toast.LENGTH_SHORT);
            return 2;
        }else if(idAccion.equals("3")){
            return 3;
        }
    return -1;
    }
    public void lanzarFuncionMostrarTodo(){
        final ListView listView=(ListView)findViewById(R.id.lstTodosContactos);
        final Button btnMostrarTodos=(Button)findViewById(R.id.btnMostrarTodos);
        final Button btnEliminarElemento=(Button)findViewById(R.id.btnEliminarElemento);
        final TextView lblElementoSeleccinado=(TextView)findViewById(R.id.lblUsuarioSeleccionado);
        arreglo= new ArrayList<>();
        adapter= new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_item,arreglo);
        listView.setClickable(true);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Object o= parent.getItemAtPosition(position);
                lblElementoSeleccinado.setText(o.toString());
            }
        });
btnEliminarElemento.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if(!lblElementoSeleccinado.getText().toString().isEmpty()){
            dao= new DaoContacto(getApplicationContext());
            dao.deleteTitle(lblElementoSeleccinado.getText().toString());
            actualizarListView();
            setResult(Activity.RESULT_OK, new Intent().putExtra("Resultado", "3"));
            finish();
        }else{
            Toast.makeText(getApplicationContext(),"NO HA SELECCIONADO UN ELEMENTO",Toast.LENGTH_SHORT).show();
        }
    }
});
        btnMostrarTodos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
        actualizarListView();
            }
        });
    }
    public void actualizarListView(){
        arreglo.clear();
        dao= new DaoContacto(getApplicationContext());
        arregloDeContactos=dao.obtenerTodos();
        for (Contacto c : arregloDeContactos){
            arreglo.add(c.usuario);
        }
        adapter.notifyDataSetChanged();
    }
    public void lanzarFuncionInsert() {
        final Button btnInsert = (Button) findViewById(R.id.btnAgregarContacto);
        final EditText textUsuario = (EditText) findViewById(R.id.txtUsuario);
        final EditText textemail = (EditText) findViewById(R.id.txtEmail);
        final EditText texttelefono = (EditText) findViewById(R.id.txtTelefono);
        final EditText textfechanacimiento = (EditText) findViewById(R.id.txtFechaNacimiento);
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!textUsuario.getText().toString().isEmpty() && !textemail.getText().toString().isEmpty() && !textfechanacimiento.getText().toString().isEmpty() && !texttelefono.getText().toString().isEmpty()) {
                    dao= new DaoContacto(getApplicationContext());
                    long a=dao.insertarContacto(new Contacto(0, textUsuario.getText() + "", textemail.getText() + "", texttelefono.getText() + "", textfechanacimiento.getText() + ""));
                    setResult(Activity.RESULT_OK, new Intent().putExtra("Resultado", "1"));
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), "Error!! Has dejado algun campo vacio", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
